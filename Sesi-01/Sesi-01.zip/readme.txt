7 layer osi
> protokol > 
  > browser (tools) 
    > edge
    > chrome
    > firefox
  
  > documents > di akses > browser (website) > localhost/server local
    > html(hyper text markup language) 
    > css (mempercantik)
    > java script (mengelola dom)
    
  > editor > ngoding/membuat kode
    > sublime
    > atom
    > notepad++
    > visual studio code (univesal) > rekomendasi
    
  > method > get
    > menampilkan data > get
    > update data > put/update
    > delete data > delete
    > simpan data > post
==============================================================================

roles:
  - backend
    > database > struktur (mysql, postgresql, sqlserver), unstruktur (mongodb, nosql)
    > logic/algoritma > (programming > php, golang, asp, dll)
    > response json/object
  - frontend > (here)
    - css > mempercantik tampilan (framework > bootstrap, tailwind, daisy ui, dll)
    - html (version 5) > responsive > media query 
    - java script > mengelola dom
    - jquery (ajax) > jembatan/penghubung > kelola programming (database) (PHP)
  - devops
  - qualitify asurance
  - dba
  - full stack
  
==============================================================================
shorcut vscode:
ctrl + shift + k > delete row
ctrl + d > blok karakter
ctrl + shift + l > block all karakter
ctrl + b > tutup/buka explorer
ctrl + j > tutup/buka terminal

cloud hosting:
- heroku (berbayar)
- github pages

==============================================================================

challange:
1. buat tugas untuk menampilkan biodata peserta:
	- nama lengkap (bold, h3)
  - alamat (background dengan berbentuk box, p)
  - hobi (list > bermain gitar, membaca puisi, bermain badminton)
  >> buatkan dalam bentuk div, dengan style internal css (background solid)
  
  output:
  	- Arif Setiawan (bold, h3)
    - Jl. Imam Bonjol, Lampung (background text, color, berbentuk box - border)
    